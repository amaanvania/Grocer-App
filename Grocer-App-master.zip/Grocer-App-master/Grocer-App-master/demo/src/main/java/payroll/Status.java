package payroll;

public enum Status {

    IN_PROGRESS,
    COMPLETED,
    CANCELLED,
    ACCEPTED,
    PENDING
}