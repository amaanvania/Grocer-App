# Grocer-App

Grocery Store application for WasteLess. Utilizes Spring-boot
